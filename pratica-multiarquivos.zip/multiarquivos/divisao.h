#ifndef DIVISAO_H
#define DIVISAO_H

float divisao(int a, int b);

#endif