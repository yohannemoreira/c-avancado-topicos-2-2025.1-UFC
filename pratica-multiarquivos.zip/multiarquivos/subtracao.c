#include "subtracao.h"

float subtracao(int a, int b) {
    return (float)(a - b);
}