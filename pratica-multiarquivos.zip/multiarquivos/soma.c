#include "soma.h"

float soma(int a, int b) {
    return (float)(a + b);
}