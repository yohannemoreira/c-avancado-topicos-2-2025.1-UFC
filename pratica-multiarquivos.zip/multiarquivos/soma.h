#ifndef SOMA_H
#define SOMA_H

float soma(int a, int b);

#endif