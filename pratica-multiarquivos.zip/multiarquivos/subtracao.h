#ifndef SUBTRACAO_H
#define SUBTRACAO_H

float subtracao(int a, int b);

#endif