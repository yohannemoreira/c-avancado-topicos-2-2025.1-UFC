#include "divisao.h"

float divisao(int a, int b) {
    return (float)a / b;
}