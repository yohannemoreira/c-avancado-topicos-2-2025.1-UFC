#ifndef MULTIPLICACAO_H
#define MULTIPLICACAO_H

float multiplicacao(int a, int b);

#endif