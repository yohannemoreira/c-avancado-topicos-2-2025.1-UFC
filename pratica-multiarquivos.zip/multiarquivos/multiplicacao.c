#include "multiplicacao.h"

float multiplicacao(int a, int b) {
    return (float)(a * b);
}